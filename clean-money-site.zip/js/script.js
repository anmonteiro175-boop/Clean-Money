function startCountdown() {
  let deadline = new Date().getTime() + (5 * 24 * 60 * 60 * 1000);

  const timer = setInterval(() => {
    const now = new Date().getTime();
    let t = deadline - now;

    if (t < 0) {
      deadline = new Date().getTime() + (5 * 24 * 60 * 60 * 1000);
      t = deadline - now;
    }

    const days = Math.floor(t / (1000 * 60 * 60 * 24));
    const hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((t % (1000 * 60)) / 1000);

    document.getElementById("countdown").innerHTML =
      "Oferta expira em: " + days + "d " + hours + "h " + minutes + "m " + seconds + "s";
  }, 1000);
}

startCountdown();
